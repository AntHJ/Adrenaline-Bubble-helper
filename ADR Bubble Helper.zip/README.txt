Created by AHJONES - I Know its not perfect, but its helpful

**ABOUT**

 This tool will resize images to the required sizes for the Adrenaline Bubble Manager
 and also convert them to 8 bit png images..

 for best results, try and use images of a similar size/ratio for its use..

	Bubble		=	128 x 128
	Background	=	840 x 500
	Start Button	=	280 x 158
	Launch Screen	=	960 x 544

	Manual pages / Additional images = 960 x 544


 The Location of the Start/Launch button can be changed from the default location

	Middle		= the same location as the Settings app
 	Right		= the same location as VitaShell
	Upper Right	= the same location as the NEAR app

	----------------------------------------------------

** TRANSFER THE FILES **

 Transfer the created folder / converted images to your Vitas UX0: so for example
 you would have something like this

	  UX0:ABM\MyGame\icon0.png
			\bg0.png
			\startup.png
			\pic0.png
			\template.xml
			\Manual\001.png
				\002.png
				\003.png

	----------------------------------------------------

** INSTALLING / INJECTING THE IMAGES **

 - Open Adrenaline bubble manager
 - Create a bubble like you normally do (to remove the PS1/PSP background on launch,
   set the option Set Img to 'No' before making the origional bubble)
 - Press O to open Bubbles Settings
 - Scroll down to find the Game/Bubble you want to change
 - Press X then find the Folder for the image set and press X
 - Press Start and the app will use these files to rebuild the bubble
 
 DONE.!